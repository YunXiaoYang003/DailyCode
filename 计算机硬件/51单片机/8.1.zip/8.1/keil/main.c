#include <reg51.h>
#include <delay.h>
#include <18b20.h>
#include <1602.h>
void main()
{ unsigned int temp; 
  float t;
  int i; 
  LCD_Init(); 
  while(1)
  {
     temp=ReadTemperature();  //�ɼ�һ���¶�ֵ
     t=temp*0.0625; //20.0625
     LCD_Write_Char(0,0,t/10+'0'); //shiwei
     for(i=0;i<100;i++)
     {DelayMs(100);}//��ʱ10s=100ms*100
  }
 }
