#define _CRT_SECURE_NO_WARNINGS 1
#define _CRT_SECURE_NO_WARNINGS 1
#pragma
#include<stdio.h>
#include<assert.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
typedef char QDataType;
typedef struct QueueNode
{
	struct Queue* next;
	QDataType data[15];
}QNode;
typedef struct Queue
{
	QNode* head;
	QNode* tail;
}Queue;
void QueueInit(Queue* pq);
void QueuePush(Queue* pq, QDataType b[]);//��β���� 
void QueuePop(Queue* pq);//��ͷ
int QueueSize(Queue* pq);//�ӵĳ���
QDataType QueueFront(Queue* pq);
QDataType QueueBack(Queue* pq);
bool QueueEmpty(Queue* pq);
void QueueDestroy(Queue* pq);