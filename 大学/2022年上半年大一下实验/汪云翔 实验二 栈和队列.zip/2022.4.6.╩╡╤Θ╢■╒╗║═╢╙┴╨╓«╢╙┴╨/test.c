#include"Queue.h"
#define _CRT_SECURE_NO_WARNINGS 1
int main(void)
{
	Queue q;
	int n,a,c;
	char b[15] = { 0 };
	while (1)
	{
		printf("1.����\n");
		printf("2.����\n");
		printf("3.�鿴�Ŷ�\n");
		printf("4.�鿴����\n");
		printf("5.�°�\n");
		printf("6.�ϰ�\n");
		scanf_s("%d", &n);
		switch (n)
		{
		case 1:printf("������\n"); 
			scanf_s("%d", &a);
			for (int i = 0; i < a; i++)
			{
				printf("the information:");
				scanf("%s", b);
				QueuePush(&q, b);
			} break;

		case 2:QueuePop(&q); break;
		case 3:while (q.head!=NULL)
		{
			printf("%s\n", q.head->data);
			QueuePop(&q);
		} break;
		case 4:if (q.head!=NULL) 
			printf("��ʱ����%dλ�ˡ�\n", QueueSize(&q));
			  else printf("��ʱû�����Ŷӡ�\n"); break;
		case 5: QueueDestroy(&q); exit(-1); break;
		case 6:QueueInit(&q); break;
		default:printf("error\n"); break;
		}
	}
	QueueDestroy(&q);
	return 0;
}