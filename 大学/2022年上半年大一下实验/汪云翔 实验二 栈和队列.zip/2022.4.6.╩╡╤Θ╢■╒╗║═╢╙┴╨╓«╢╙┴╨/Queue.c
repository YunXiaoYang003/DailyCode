#include"Queue.h"
#define _CRT_SECURE_NO_WARNINGS 1
void QueueInit(Queue* pq)
{
	pq->head = pq->tail = NULL;
}
void QueuePush(Queue* pq, QDataType b[])//��β����
{
	QNode* NewNode = (QNode*)malloc(sizeof(QNode));
	for (int i = 0; i < strlen(b)+1; i++)
	{
         NewNode->data[i] = b[i];
	}	
	NewNode->next = NULL;
	if (NewNode == NULL)
	{
		printf("error!");
		exit(-1);
	}
	else
	{
		if (pq->tail == NULL)
		{
			pq->head = pq->tail = NewNode;
		}
		else
		{
			pq->tail->next = NewNode;//��β
			pq->tail = NewNode;//���¶�β
		}
	}
}
void QueuePop(Queue* pq)//��ͷɾ��
{
	assert(pq);
	assert(pq->head && pq->tail);
	if (pq->head->next == NULL)
	{
		free(pq->head);
		pq->head = pq->tail = NULL;
	}
	else
	{
		QNode* next = pq->head->next;
		free(pq->head);
		pq->head = next;
	}
}
int QueueSize(Queue* pq)//�ӵĳ���
{
	assert(pq);
	int size = 0;
	QNode* cur = pq->head;
	while (cur)
	{
		++size;
		cur = cur->next;
	}
	return size;
}
bool QueueEmpty(Queue* pq)
{
	assert(pq);
	return pq->head == NULL;
}
void QueueDestroy(Queue* pq)
{
	assert(pq);
	QNode* cur = pq->head;
	while (cur)
	{
		QNode* next = cur->next;
		free(cur);
		cur = next;
	}
	pq->head = pq->tail = NULL;
}

