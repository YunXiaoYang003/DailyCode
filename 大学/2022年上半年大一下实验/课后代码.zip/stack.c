#include"stack.h"
void stackInit(ST* ps)
{
	assert(ps);
	ps->a = (STDatatype*)malloc(sizeof(STDatatype) * 4);
	ps->top = 0;//ջ��ָ��ջ��Ԫ�ص���һ��
	ps->capacity = 4;
}
void stackDestory(ST* ps)
{
	assert(ps);
	ps->top = 0;
}
void stackCheckCreat(ST* ps)
{
	assert(ps);
	if (ps->top >= ps->capacity)
	{
		ps->capacity *= 2;
		ps->a = (STDatatype*)realloc(ps->a, sizeof(STDatatype) * ps->capacity);
		if (ps->a == NULL)
		{
			printf("error\n");
			exit(-1);
		}
	}
}
void stackPush(ST* ps, STDatatype x)
{
	assert(ps);
	stackCheckCreat(ps);
	ps->a[ps->top] = x;
	ps->top++;
	stackCheckCreat(ps);
}
void stackPop(ST* ps)
{
	assert(ps);//��ջ���ˣ�ֱ����ֹ���򲢱�����
	assert(ps->top > 0);
	ps->top--;
}
STDatatype stackTop(ST* ps)
{
	assert(ps);
	return ps->a[ps->top - 1];//ջ����ֵ
}
int  stackSize(ST* ps)
{
	assert(ps);
	assert(ps->top > 0);
	return ps->top;//ջ�ĳ��� 
}
bool stackEmpty(ST* ps)
{
	assert(ps);
	/*ps->top = 0;
	return ps->top == 0;*/
	if (ps->top > 0)
	{
		return false;
	}
	else
	{
		return true;
	}
}
void stackPrint(ST* ps)
{
	assert(ps);
	while (!stackEmpty(ps))
	{
		printf("%d ", stackTop(ps));
		stackPop(ps);
	}
	printf("\n");
}
