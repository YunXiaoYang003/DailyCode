#include<iostream>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
 
using namespace std;
#define MAXSIZE 100
 
typedef struct 
{
	int num;
	char name[20];
	int score;
	int score2;
}Student;
 
typedef struct{
	Student elem[MAXSIZE];
	int last;
}Sqlist;
 
int InitList(Sqlist *L);
void DirectInsertSort(Sqlist *L, int left, int right);
void QuickSort(Sqlist *L, int low, int high);
int BinSearch(Sqlist *L, int n, int k);
int Locate(Sqlist *L, Student e);
int BubbleSort(Sqlist *L, int n);
void ShowList(Sqlist *L,int n);
void ShowList2(Sqlist *L,int n);
void menu();
 
 
int main()
{
 
	int i,temp1,temp2,sum,select=1,bin=0;
	Sqlist L;
	Student m,e;
	while(select)
	{
		menu();
		cout<<"��ѡ����Ҫ������ѡ��:";
		cin>>select;
		cout<<endl;
		switch(select)
		{
			case 1: //��Ϣ��ʼ��
			sum=InitList(&L);
			system("pause");
			system("cls");
			break;
 
			case 2: //˳�����
			cout<<"��������Ҫ���ҵ�����"<<endl;
			cin>>e.name;
			temp1=Locate(&L,e);
			ShowList2(&L,temp1);
			system("pause");
			system("cls");
			break;
 
			case 3:
			cout<<"������Ҫ���ҵ�ѧ��ѧ��:";
			cin>>bin;
			
			temp2=BinSearch(&L,sum,bin);
			ShowList2(&L,temp2);
			system("pause");
			system("cls");
			break;
 
			case 4:
			cout<<"����ֱ�Ӳ�������ǰ��"<<endl;
			ShowList(&L,sum);
			cout<<"����ֱ�Ӳ��������"<<endl;
			DirectInsertSort(&L, 0, sum-1);
			ShowList(&L,sum);
			system("pause");
			system("cls");
			break;
 
			case 5:
			BubbleSort(&L,sum);
			ShowList(&L,sum);
			system("pause");
			system("cls");
			break;
 
			case 6:
			QuickSort(&L,0,sum-1);
			ShowList(&L,sum);
			system("pause");
			system("cls");
			break;
			
			case 0:
			exit(0);
 
		}
 
	}
 
}
 
 
void menu()
{
	cout<<"*******************ѧ���ɼ�����ϵͳ*****************"<<endl;
	cout<<"*         1����Ϣ��ʼ��        2��˳�����         *"<<endl;
	cout<<"*         3�����ֲ���          4��ֱ�Ӳ�������     *"<<endl;
	cout<<"*         5��ð�ݻ�ѡ������    6����������         *"<<endl;
	cout<<"*         0���˳�                                  *"<<endl;
	cout<<"****************************************************"<<endl;
 
}
 
void ShowList(Sqlist *L,int n)
{
	for(int i=0;i<n;i++)
	{
		cout<<"ѧ��\t"<<"����\t"<<"���ݽṹ\t"<<"�������\t"<<endl;
		cout<<L->elem[i].num<<"\t"<<L->elem[i].name<<"\t"<<L->elem[i].score<<"\t\t"<<L->elem[i].score2<<endl;
	}
}
 
int InitList(Sqlist *L)
{
	int x=0,sum=0;
	cout<<"������ѧ����������"<<endl;
			cin>>x;
			sum=x;
			for(int i=0; i<x; i++)
			{
				cout<<"��"<<i+1<<"λѧ����Ϣ"<<endl;
				cout<<"ѧ��:";
				cin>>L->elem[i].num;
				cout<<"-----------------------------"<<endl;
				cout<<"����:";
				cin>>L->elem[i].name;
				cout<<"-----------------------------"<<endl;
				cout<<"���ݽṹ:";
				cin>>L->elem[i].score;
				cout<<"-----------------------------"<<endl;
				cout<<"�������:";
				cin>>L->elem[i].score2;
				cout<<"-----------------------------"<<endl;
 
			}
			L->last=x;
			return sum;
			cout<<endl;
}
 
int Locate(Sqlist *L, Student e)
{
	int i;
	for(i=0;i<L->last;i++)//�ȽϺ���
	{
		if(strcmp(L->elem[i].name, e.name)==0)
			return i+1;
	}
	//return 0;
 
}
 
int BinSearch(Sqlist *L, int n, int k)
{
	int low = 0, high =n-1,mid;//n-1
	while(low<=high)
	{
		mid=(low+high)/2;
		if(k==L->elem[mid].num)
			return mid+1;
		if(k< L->elem[mid].num)
			high=mid-1;
		else
			low=mid+1;
 
	}
	return 0;
 
}
 
void DirectInsertSort(Sqlist *L, int left, int right)
{
	Student t;
	for (int i = left; i <= right; ++i)
	{
		for (int j = i - 1; j >= 0 && strcmp(L->elem[j].name,L->elem[j+1].name)>0; --j) 
		{
				t=L->elem[j];
  				L->elem[j]=L->elem[j+1];
  				L->elem[j+1]=t;
		}
	}
}
 
 
int BubbleSort(Sqlist *L, int n)
{
	int i,j;
	Student t;
	for(i=0;i<n-1;i++)
  	{
  		for(j=n-1;j>i;j--)
  		{
  			if(L->elem[j-1].score > L->elem[j].score)
  			{
  				t=L->elem[j-1];
  				L->elem[j-1]=L->elem[j];
  				L->elem[j]=t;
			  }
		  }
	  }
	  return 0;
  	
}
 
void QuickSort(Sqlist *L, int low, int high)
{
	 int i=low,j=high;  
    Student pivotvalue=L->elem[i];  
    if(low>=high)  
        return;   
    while(i<j)
    {
        while(i<j&&L->elem[j].score2>=pivotvalue.score2)
            j--;
        L->elem[i]=L->elem[j];
        while(i<j&&L->elem[i].score2<=pivotvalue.score2)
            i++;
        L->elem[j]=L->elem[i];
    }
    L->elem[i]=pivotvalue;
    QuickSort(L,low,i-1);
    QuickSort(L,i+1,high);
}
 
void ShowList2(Sqlist *L,int n)
{
		if(n!=0)
			{
			
				cout<<"ѧ��\t"<<"����\t"<<"���ݽṹ\t"<<"�������\t"<<endl;
				cout<<L->elem[n-1].num<<"\t"<<L->elem[n-1].name<<"\t"<<L->elem[n-1].score<<"\t\t"<<L->elem[n-1].score2<<endl;
			}
			else
				cout<<"����ʧ��"<<endl;
}
 
 
 
