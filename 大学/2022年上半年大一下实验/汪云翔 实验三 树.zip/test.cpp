#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<stdlib.h>
typedef char BTDataType;
typedef struct BinaryTreeNode
{
	BTDataType data;
	struct BinaryTreeNode* left;
	struct BinaryTreeNode* right;
}BTNode;
BTNode* BuyNode(BTDataType x)//���ٿռ�洢����
{
	BTNode* newnode = (BTNode*)malloc(sizeof(BTNode));
	newnode->data = x;
	newnode->left = NULL;
	newnode->right = NULL;
	return newnode;
}
void prev_order(BTNode* root)//ǰ�����
{
	if (root == NULL)
	{
		return;
	}
	printf("%c ", root->data);
	prev_order(root->left);
	prev_order(root->right);
}
void on_order(BTNode* root)//�������
{
	if (root == NULL)
	{
		return;
	}
	prev_order(root->left);
	printf("%c ", root->data);
	prev_order(root->right);
}
void post_order(BTNode* root)//�������
{
	if (root == NULL)
	{
		return;
	}
	prev_order(root->left);
	prev_order(root->right);
	printf("%c    ", root->data);
}
int main(void)
{
	BTNode* n1 = BuyNode('A');
	BTNode* n2 = BuyNode('B');
	BTNode* n3 = BuyNode('C');
	BTNode* n4 = BuyNode('D');
	BTNode* n5 = BuyNode('E');
	BTNode* n6= BuyNode('F');
	BTNode* n7 = BuyNode('G');
	BTNode* n8 = BuyNode('H');
	n1->left = n2;
	n1->right = n3;
	n2->left = n4;
	n2->right = n5;
	n3->right = n6;
	n5->left = n7;
	n5->right = n8;
	prev_order(n1);
	printf("\n");
	on_order(n1);
	printf("\n");
	post_order(n1);
	printf("\n");
	return 0;
}