#ifndef __DELAY_H__
#define __DELAY_H__

void SendByte(unsigned char dat);

void SendStr(unsigned char *s);

#endif